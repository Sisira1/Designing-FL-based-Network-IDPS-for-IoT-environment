import pandas as pd

# Load the dataset
file_path = r"C:\Users\userPC\Desktop\Sample FL\binary_standardized_data.csv"
df = pd.read_csv(file_path)

# Display the first few rows of the dataset
print("First 5 rows of the dataset:")
print(df.head())

# Get the total number of columns (features + label)
total_columns = df.shape[1]

# Assuming the last column is the label, the number of features is total_columns - 1
num_features = total_columns - 1

print(f"\nTotal number of features: {num_features}")

import pandas as pd

# Load the dataset
file_path = r"C:\Users\userPC\Desktop\Sample FL\binary_standardized_data.csv"
df = pd.read_csv(file_path)

# Display the column names
print("Column names in the dataset:")
print(df.columns)

# Separate features and label
feature_columns = df.columns[:-1]  # All columns except the last one
label_column = df.columns[-1]      # The last column

print("\nFeatures:")
print(feature_columns.tolist())

print("\nLabel/Target:")
print(label_column)