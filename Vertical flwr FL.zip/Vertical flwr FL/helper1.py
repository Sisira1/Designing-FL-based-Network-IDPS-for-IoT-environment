import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from typing import List


def load_dataset(client_id: int):
    # Load the dataset
    df = pd.read_csv(r"C:\Users\userPC\Desktop\vertical new fl\binary_standardized_data.csv")

    # Separate features (X) and labels (y)
    X = df.iloc[:, :-1]
    y = df.iloc[:, -1]

    # Split the features vertically into 6 clients
    num_clients = 6
    num_features = X.shape[1]
    features_per_client = num_features // num_clients

    # Assign features to each client
    start_idx = client_id * features_per_client
    end_idx = (client_id + 1) * features_per_client if client_id != num_clients - 1 else num_features

    # Extract the subset of features for this client
    X_client = X.iloc[:, start_idx:end_idx]

    # Split the data into training and testing sets (80% training, 20% testing)
    X_train, X_test, y_train, y_test = train_test_split(X_client, y, train_size=0.8, random_state=42)

    return X_train, y_train, X_test, y_test


# Get the parameters from the RandomForestClassifier
def get_params(model: RandomForestClassifier) -> List[np.ndarray]:
    params = [
        model.n_estimators,
        model.max_depth,
        model.min_samples_split,
        model.min_samples_leaf,
    ]
    return params


# Set the parameters in the RandomForestClassifier
def set_params(model: RandomForestClassifier, params: List[np.ndarray]) -> RandomForestClassifier:
    model.n_estimators = int(params[0])
    model.max_depth = int(params[1])
    model.min_samples_split = int(params[2])
    model.min_samples_leaf = int(params[3])
    return model